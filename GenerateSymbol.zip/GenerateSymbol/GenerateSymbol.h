// Copyright 2016 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// You may freely redistribute and use this sample code, with or
// without modification, provided you include the original copyright
// notice and use restrictions.
//
// See the Sample code usage restrictions document for further information.
//

#ifndef GENERATESYMBOL_H
#define GENERATESYMBOL_H

namespace Esri
{
namespace ArcGISRuntime
{
class Map;
class MapGraphicsView;
class Basemap;
}
}

#include <QMainWindow>
#include "GraphicsOverlay.h"

class GenerateSymbol : public QMainWindow
{
    Q_OBJECT
public:
    GenerateSymbol(QWidget *parent = 0);
    ~GenerateSymbol();

public slots:

private:
    Esri::ArcGISRuntime::Map* m_map;
    Esri::ArcGISRuntime::MapGraphicsView* m_mapView;
    void createMessages();
    Esri::ArcGISRuntime::GraphicsOverlay* grLayer;
    QList<Esri::ArcGISRuntime::Graphic*> lse;
};

#endif // GENERATESYMBOL_H
