// Copyright 2016 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// You may freely redistribute and use this sample code, with or
// without modification, provided you include the original copyright
// notice and use restrictions.
//
// See the Sample code usage restrictions document for further information.
//

#include "GenerateSymbol.h"

#include "Map.h"
#include "MapGraphicsView.h"
#include "Basemap.h"
#include "PointBuilder.h"
#include "SimpleMarkerSymbol.h"
#include <QTimer>
#include "ArcGISMapImageLayer.h"
#include <QBoxLayout>
#include <QRadioButton>
#include <QGraphicsProxyWidget>
#include <QtConcurrent>

using namespace Esri::ArcGISRuntime;

GenerateSymbol::GenerateSymbol(QWidget *parent)
    : QMainWindow(parent)
{
    // create a new basemap instance
    //Basemap* basemap = Basemap::oceans(this);
    // create a new map instance
     //m_map = new Map(basemap, this);

    Esri::ArcGISRuntime::ArcGISMapImageLayer *layer = new Esri::ArcGISRuntime::ArcGISMapImageLayer(QUrl("http://server.arcgisonline.com/arcgis/rest/services/ESRI_Imagery_World_2D/MapServer"));
    Esri::ArcGISRuntime::Basemap* basemap = new Esri::ArcGISRuntime::Basemap(layer);
    m_map = new Esri::ArcGISRuntime::Map(basemap, this);
    // create an new mapView instance
    m_mapView = new MapGraphicsView(m_map,this);

    grLayer = new GraphicsOverlay(this);

    m_mapView->graphicsOverlays()->append(grLayer);

    // set the mapView as the central widget
    setCentralWidget(m_mapView);

    QTimer* timer = new QTimer();
        connect(timer, &QTimer::timeout, [this]() {

          QtConcurrent::run(this,&GenerateSymbol::createMessages);    // working
         // createMessages();
    //      m_mapView->setViewpointCenter(Esri::ArcGISRuntime::Point(0, 0));  // not working
    //      m_mapView->setViewpointCenter(Esri::ArcGISRuntime::Point(0, 0), 3000000);  // not working
        } );

    // move the mapcenter manually using the mouse in the meantime
        timer->start(8000);
      //  timer->setSingleShot(true);
        timer->setInterval(4000);

        QWidget* widget = new QWidget();
        QPalette pal(palette());
        pal.setColor(QPalette::Background, Qt::white);
       // widget->setAutoFillBackground(true);
        widget->setPalette(pal);

        QVBoxLayout* verticalLayout = new QVBoxLayout();
        QRadioButton* m_rdTrueMt = new QRadioButton(tr("TRUE MOTION"));
        QRadioButton* m_rdNorthUp = new QRadioButton(tr("NORTH UP"));
        QRadioButton* m_rdHeadingUp = new QRadioButton(tr("HEADING UP"));
        m_rdTrueMt->setChecked(true);

       // m_mouseHelper = new MSA_MouseHelper(m_mapGraphicsView,m_rdHeadingUp,m_rdNorthUp);


        //connect(m_rdTrueMt, SIGNAL(toggled(bool)), this, SLOT(onToggle(bool)));
        //connect(m_rdNorthUp, SIGNAL(toggled(bool)), this, SLOT(onToggle(bool)));
        //connect(m_rdHeadingUp, SIGNAL(toggled(bool)), this, SLOT(onToggle(bool)));

        verticalLayout->addWidget(m_rdTrueMt);
        verticalLayout->addWidget(m_rdNorthUp);
        verticalLayout->addWidget(m_rdHeadingUp);


        widget->setLayout(verticalLayout);
        QGraphicsProxyWidget *proxy = m_mapView->scene()->addWidget(widget);
        proxy->setPos(7, 7);
     //   proxy->setPalette(pal);
        //widget->setProxyWidGet(proxy);


}

void GenerateSymbol::createMessages(){
    int max =100;
    qsrand(QTime::currentTime().msec());



   // grLayer->removeAll();

    grLayer->graphics()->clear();



    Esri::ArcGISRuntime::SpatialReference spatialReference(4326);
    qDebug() << m_mapView->visibleArea().extent().xMax() << " maxx";
    qDebug() << m_mapView->visibleArea().extent().xMin() << " minx";
    qDebug() << m_mapView->visibleArea().extent().yMax() << " maxy";
    qDebug() << m_mapView->visibleArea().extent().yMin() << " miny";


      // add simple marker symbols

      //EsriRuntimeQt::Point point1(-2.25769e+07, -30241000, spatialReference);
      //EsriRuntimeQt::Point point2(600000, 3800000, spatialReference);
      //EsriRuntimeQt::Point point3(8300050, 1750000, spatialReference);

     // Esri::ArcGISRuntime::SimpleMarkerSymbol blueDiamond(Esri::ArcGISRuntime::SimpleMarkerSymbolStyle::Diamond);
     // blueDiamond.setSize(16);
     // blueDiamond.setColor(Qt::blue);

      Esri::ArcGISRuntime::Graphic* graphicz;
      Esri::ArcGISRuntime::PointBuilder pntbuild(spatialReference);

      bool isupdate = grLayer->graphics()->size()>0;



      for(int z = 0 ; z<max ; z++){
          /*
          if(isupdate){
            //  qDebug()<<grLayer->graphics()->size() << " esiste";
              pntbuild.setXY(((qrand() % (int)((53 + 1) +18)) -18),((qrand() % (int)((68 + 1) +14)) -14));
             // p.setY(((qrand() % (int)((1.99719e+07 + 1) +1.99719e+07)) -1.99719e+07));
              Esri::ArcGISRuntime::SimpleMarkerSymbol* redCircle = new Esri::ArcGISRuntime::SimpleMarkerSymbol(Esri::ArcGISRuntime::SimpleMarkerSymbolStyle::Circle,Qt::red, 8 );
              graphicz = new Esri::ArcGISRuntime::Graphic(pntbuild.toPoint(), redCircle);
              //lse.at(z)->setGeometry(graphicz->geometry());
            //  lse.at(z)->setSymbol(graphicz->symbol());
           // grLayer->graphics()->append(graphicz);
              delete redCircle;
              delete graphicz;

          }else{
               Esri::ArcGISRuntime::SimpleMarkerSymbol* redCircle = new Esri::ArcGISRuntime::SimpleMarkerSymbol(Esri::ArcGISRuntime::SimpleMarkerSymbolStyle::Circle,Qt::red, 8 );
              pntbuild.setXY(((qrand() % (int)((53 + 1) +18)) -18),((qrand() % (int)((68 + 1) +14)) -14));
            //  p.setX(((qrand() % (int)((2.25769e+07 + 1) +2.25769e+07)) -2.25769e+07));
             // p.setY(((qrand() % (int)((1.99719e+07 + 1) +1.99719e+07)) -1.99719e+07));
              graphicz = new Esri::ArcGISRuntime::Graphic(pntbuild.toPoint(), redCircle);
              grLayer->graphics()->append(graphicz);
              lse.append(graphicz);
              delete redCircle;

          }*/

          Esri::ArcGISRuntime::SimpleMarkerSymbol* redCircle = new Esri::ArcGISRuntime::SimpleMarkerSymbol(Esri::ArcGISRuntime::SimpleMarkerSymbolStyle::Circle,Qt::red, 8 );
         pntbuild.setXY(((qrand() % (int)((53 + 1) +18)) -18),((qrand() % (int)((68 + 1) +14)) -14));
         graphicz = new Esri::ArcGISRuntime::Graphic(pntbuild.toPoint(), redCircle);
         grLayer->graphics()->append(graphicz);
         delete redCircle;

      }




}



// destructor
GenerateSymbol::~GenerateSymbol()
{

}
